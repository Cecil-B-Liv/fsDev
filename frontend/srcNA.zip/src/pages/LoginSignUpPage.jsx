import React from "react";
import LoginComponent from "../components/LoginComponent";
import NotificationComponent from "../components/NotificationComponent";
import ProfileComponent from "../components/ProfileComponent";

function LoginSignupPage() {
  return (
    <>
      <div>
        {/* <LoginComponent/>
        <NotificationComponent></NotificationComponent> */}
        <ProfileComponent />
      </div>
    </>
  );
}

export default LoginSignupPage;
